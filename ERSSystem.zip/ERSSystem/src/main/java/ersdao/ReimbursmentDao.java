package ersdao;


import ersmodel.com.ReimModel;

public interface ReimbursmentDao {
	public void addReimbursment(ReimModel r);
}
